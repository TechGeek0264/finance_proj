# finance_app/forms.py

from django import forms

class FinanceForm(forms.Form):
    margin = forms.FloatField(
        label='Margin', 
        min_value=0,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    
