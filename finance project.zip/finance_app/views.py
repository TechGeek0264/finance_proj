# finance_app/views.py

from django.views.generic import FormView
from django.urls import reverse_lazy
from .forms import FinanceForm
from .models import FinanceCalculation

class CalculateFinanceView(FormView):
    template_name = 'finance_app/calculate_finance.html'
    form_class = FinanceForm
    success_url = reverse_lazy('calculate_finance')

    def form_valid(self, form):
        margin = form.cleaned_data['margin']

        initial_rate = margin + 4.99
        expected_rate = initial_rate - 0.98
        cap_on_interest_rate = initial_rate + 5.00
        initial_loc_growth = initial_rate + 0.50
        principal_limit = -14025.33 * margin + 162024

        # Assuming a fixed home value and MIP for display purposes
        home_value = 314000  # Example value
        mip = 0.5  # Example calculation for MIP

        calculation = FinanceCalculation.objects.create(
            margin=margin,
            home_value=home_value,
            age=0,  # Age is no longer used, so setting it to a default value
            initial_rate=initial_rate,
            expected_rate=expected_rate,
            cap_on_interest_rate=cap_on_interest_rate,
            initial_loc_growth=initial_loc_growth,
            principal_limit=principal_limit
        )

        result = {
            'initial_rate': initial_rate,
            'expected_rate': expected_rate,
            'cap_on_interest_rate': cap_on_interest_rate,
            'initial_loc_growth': initial_loc_growth,
            'principal_limit': principal_limit,
            'home_value': home_value,
            'mip': mip
        }

        return self.render_to_response(self.get_context_data(form=form, result=result))
