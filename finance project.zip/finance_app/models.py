from django.db import models

class FinanceCalculation(models.Model):
    margin = models.FloatField()
    home_value = models.FloatField()
    age = models.IntegerField()
    initial_rate = models.FloatField()
    expected_rate = models.FloatField()
    cap_on_interest_rate = models.FloatField()
    initial_loc_growth = models.FloatField()
    principal_limit = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Calculation {self.id} at {self.created_at}"
